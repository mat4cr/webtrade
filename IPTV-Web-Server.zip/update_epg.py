# -*- coding: utf-8 -*-
import os
from providers.stvcz import stvcz

print("Začínám stahovat 7denní EPG ze SledovaniTV...")
print("Prosím čekejte, může to trvat i 20 vteřin, abychom nedostali ban na API.")

try:
    xml_data = stvcz.get_epg_xml()

    # Uloží výsledek do fyzického souboru epg.xml v hlavní složce
    with open("epg.xml", "w", encoding="utf-8") as f:
        f.write(xml_data)

    print("HOTOVO! EPG bylo úspěšně uloženo do souboru 'epg.xml'.")
except Exception as e:
    print(f"Chyba při stahování EPG: {e}")