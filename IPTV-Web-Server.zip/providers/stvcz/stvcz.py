#-*-coding:utf8;-*-

import requests, json, os, time
from datetime import datetime, timedelta
from xml.sax.saxutils import escape
from providers.stvcz.login import pin

channels = {}
headers = {"User-Agent": "okhttp/3.12.12"}
kd = "h265"
adaptive = "%2Cvast%2Cclientvast%2Cadaptive2%2Cwebvtt"
_cached_sessid = ""

try:
    with open("./providers/stvcz/stvcz_data.json", 'r') as openfile:
        data = json.load(openfile)
    deviceId = data["deviceId"]
    passwordId = data["password"]
except:
    deviceId = ""
    passwordId = ""

def get_sessid():
    global _cached_sessid
    if _cached_sessid != "":
        return _cached_sessid
        
    phpsessid = ""
    req = requests.get("https://sledovanitv.cz/api/device-login?deviceId=" + str(deviceId) + "&password=" + str(passwordId) + "&version=2.44.16&lang=cs&unit=default&capabilities=" + adaptive, headers = headers).json()
    if req.get("status") == 1:
        phpsessid = req["PHPSESSID"]
        requests.get("http://sledovanitv.cz/api/pin-unlock?pin=" + str(pin) + "&PHPSESSID=" + phpsessid, headers = headers).json()
        _cached_sessid = phpsessid
    return phpsessid

sessid = get_sessid()
if sessid != "":
    req = requests.get("https://sledovanitv.cz/api/get-stream-qualities?PHPSESSID=" + sessid).json()
    q = []
    for x in req["qualities"]:
        if x["allowed"] == 1:
            q.append(x["id"])
    q.sort()
    quality = str(q[-1])
    req = requests.get("https://sledovanitv.cz/api/playlist?quality=" + quality + "&capabilities=" + kd + adaptive + "&force=true&format=m3u8&type=&logosize=96&whitelogo=true&drm=&subtitles=1&PHPSESSID=" + sessid, headers = headers).json()
    if req.get("status") == 1:
        groups = req.get("groups", {})
        for d in req.get("channels", []):
            if d.get("locked") == "none":
                channels[d["id"]] = {"name": d["name"], "url": d["url"], "logo": d.get("logoUrl", ""), "type": d.get("type", "tv"), "group": groups.get(d.get("group"), "")}

def get_catchup(id, utc, utcend):
    id = id.split(".")[0]
    date_time_start = datetime.fromtimestamp(int(utc) + 60)
    d_start = date_time_start.strftime("%Y-%m-%d+%H:%M:%S")
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    
    sessid = get_sessid()
    if not sessid:
        return url
        
    try:
        req = requests.get("http://sledovanitv.cz/api/epg?time=" + d_start + "&duration=1439&detail=poster&channels=" + id + "&PHPSESSID=" + sessid, headers = headers).json()
        
        if req.get("status") == 1:
            ch_data = req.get("channels", {}).get(id, [])
            
            if isinstance(ch_data, dict):
                ch_data = list(ch_data.values())
                
            if ch_data:
                event = ch_data[0]
                eventId = event.get("eventId")
                
                req_ts = requests.get("https://sledovanitv.cz/api/event-timeshift?format=m3u8&quality=" + quality + "&capabilities=" + kd + adaptive + "&force=true&eventId=" + str(eventId) + "&overrun=1&PHPSESSID=" + sessid, headers = headers).json()
                
                if req_ts.get("status") == 1:
                    url = req_ts.get("url", url)
                    
                    try:
                        start_str = event.get("startTime")
                        if start_str:
                            if start_str.count(":") == 1:
                                event_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M")
                            else:
                                event_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
                                
                            offset_sec = max(0, int(utc) - int(event_dt.timestamp()))
                            
                            # Pokud přehrávač žádá posunutý čas, provedeme proxy ořez!
                            if offset_sec > 0:
                                resp = requests.get(url, timeout=10)
                                if resp.status_code == 200:
                                    m3u8_text = resp.text
                                    base_url = url.rsplit('/', 1)[0] + '/'
                                    
                                    # Ošetření, pokud nám SledovaniTV pošle Master playlist
                                    if "#EXTINF" not in m3u8_text and "#EXT-X-STREAM-INF" in m3u8_text:
                                        lines = m3u8_text.splitlines()
                                        var_url = None
                                        for line in lines:
                                            if line.strip() and not line.startswith("#"):
                                                var_url = line.strip()
                                                break
                                        if var_url:
                                            if not var_url.startswith("http"):
                                                var_url = base_url + var_url
                                            v_resp = requests.get(var_url, timeout=10)
                                            if v_resp.status_code == 200:
                                                m3u8_text = v_resp.text
                                                base_url = var_url.rsplit('/', 1)[0] + '/'
                                                
                                    # Samotný střih segmentů
                                    if "#EXTINF" in m3u8_text:
                                        lines = m3u8_text.splitlines()
                                        out_lines = []
                                        accum = 0.0
                                        skip = False
                                        
                                        for line in lines:
                                            if skip:
                                                skip = False
                                                continue
                                                
                                            if line.startswith("#EXTINF:"):
                                                try:
                                                    dur = float(line.split(":")[1].split(",")[0])
                                                except Exception:
                                                    dur = 0.0
                                                
                                                if accum + dur <= offset_sec:
                                                    accum += dur
                                                    skip = True
                                                    continue
                                                else:
                                                    out_lines.append(line)
                                                    accum += dur
                                            elif line.startswith("#"):
                                                # Odstraníme starou Media sekvenci, vygenerujeme vlastní
                                                if line.startswith("#EXT-X-MEDIA-SEQUENCE"):
                                                    continue
                                                out_lines.append(line)
                                            else:
                                                if line.strip() == "":
                                                    continue
                                                if not line.startswith("http"):
                                                    line = base_url + line
                                                out_lines.append(line)
                                                
                                        if out_lines and out_lines[0].startswith("#EXTM3U"):
                                            out_lines.insert(1, "#EXT-X-MEDIA-SEQUENCE:0")
                                            
                                        return "\n".join(out_lines)
                    except Exception as e:
                        print(f"Chyba při řezání M3U8: {e}")
                        pass
    except Exception as e:
        print(f"Kritická chyba archivu: {e}")
        
    return url

def get_epg_xml():
    sessid = get_sessid()
    if not sessid:
        return '<?xml version="1.0" encoding="UTF-8"?><tv><error>No session ID</error></tv>'

    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<tv generator-info-name="IPTV-Web-Server">']

    channel_ids = list(channels.keys())
    for ch_id in channel_ids:
        name = escape(channels.get(ch_id, {}).get("name", ch_id))
        logo = escape(channels.get(ch_id, {}).get("logo", ""))
        xml.append(f'  <channel id="{ch_id}">')
        xml.append(f'    <display-name>{name}</display-name>')
        xml.append(f'    <icon src="{logo}" />')
        xml.append('  </channel>')

    now = datetime.now()
    chunk_size = 50

    def parse_time(t_val):
        t_str = str(t_val)
        if ":" in t_str:
            if t_str.count(":") == 1:
                dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M")
            else:
                dt = datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
        else:
            dt = datetime.fromtimestamp(int(t_val))
        return dt.strftime("%Y%m%d%H%M%S ") + time.strftime("%z")

    for days_back in range(7, -2, -1):
        target_date = now - timedelta(days=days_back)
        d_start = target_date.strftime("%Y-%m-%d+00:00:00")

        for i in range(0, len(channel_ids), chunk_size):
            chunk = channel_ids[i:i + chunk_size]
            ch_str = ",".join(chunk)

            url = f"https://sledovanitv.cz/api/epg?time={d_start}&duration=1440&detail=poster&channels={ch_str}&PHPSESSID={sessid}"
            
            try:
                response = requests.get(url, headers=headers, timeout=15)
                req = response.json()

                if req.get("status") == 1:
                    ch_data = req.get("channels", {})
                    for ch_id, events in ch_data.items():
                        if isinstance(events, dict):
                            events = list(events.values())
                            
                        for event in events:
                            title = escape(event.get("title", "Neznámý pořad"))
                            desc = escape(event.get("description", ""))
                            
                            start_val = event.get("startTime")
                            end_val = event.get("endTime")
                            
                            try:
                                start_time = parse_time(start_val)
                                end_time = parse_time(end_val)
                            except Exception:
                                continue 
                            
                            xml.append(f'  <programme start="{start_time}" stop="{end_time}" channel="{ch_id}">')
                            xml.append(f'    <title>{title}</title>')
                            if desc:
                                xml.append(f'    <desc>{desc}</desc>')
                            xml.append('  </programme>')
                else:
                    err_msg = escape(str(req.get("error", "Unknown API Error")))
                    xml.append(f'  ')
            except Exception as e:
                xml.append(f'  ')

    xml.append('</tv>')
    return "\n".join(xml)