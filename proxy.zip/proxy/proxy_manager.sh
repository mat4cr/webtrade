#!/bin/bash

# ==========================================
# Konfigurace
# ==========================================
ZDROJE_FILE="odkazy.txt"
DB_FILE="proxy_db_ready.txt"
LIVE_FILE="live_proxies.txt"

# Vyčištění staré databáze před novým během
> "$DB_FILE"

echo "[*] Čtu soubor s odkazy: $ZDROJE_FILE"

# Ošetření chybějícího souboru
if [ ! -f "$ZDROJE_FILE" ]; then
    echo "[!] Soubor $ZDROJE_FILE neexistuje. Vytvořte ho a vložte do něj URL adresy."
    exit 1
fi

# ==========================================
# Čtení odkazů a těžba (Scraping) proxy
# ==========================================
# Čte soubor řádek po řádku
while read -r line || [ -n "$line" ]; do
    # Ignorování prázdných řádků a komentářů
    [[ -z "$line" || "$line" =~ ^# ]] && continue

    # Rozdělení řádku na URL a volitelný PROTOKOL
    URL=$(echo "$line" | awk '{print $1}')
    PROTO=$(echo "$line" | awk '{print $2}')

    # Pokud protokol není u odkazu vypsán, zkusíme ho uhodnout z URL (default: http)
    if [ -z "$PROTO" ]; then
        if [[ "${URL,,}" == *"socks5"* ]]; then PROTO="socks5"
        elif [[ "${URL,,}" == *"socks4"* ]]; then PROTO="socks4"
        else PROTO="http"
        fi
    fi

    echo "  [+] Stahuji a doluji ($PROTO): $URL"

    # KOUZLO S REGULÁRNÍMI VÝRAZY:
    # 1. curl -s --max-time 10 stáhne obsah (timeout 10 sekund, pokud je server mrtvý)
    # 2. grep -oE vyřízne Z JAKÉHOKOLIV TEXTU pouze pattern IP:PORT
    # 3. sed přidá na začátek správný protokol (např. socks5://)
    # 4. >> vše připojí do naší databáze
    curl -s --max-time 10 "$URL" | \
    grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}:[0-9]{1,5}\b' | \
    sed "s/^/${PROTO}:\/\//" >> "$DB_FILE"

done < "$ZDROJE_FILE"

# ==========================================
# Úklid a odstranění duplicit
# ==========================================
# Je časté, že různé seznamy obsahují stejné IP adresy. Toto je vymaže.
sort -u "$DB_FILE" -o "$DB_FILE"

TOTAL=$(wc -l < "$DB_FILE")
echo "[*] Dolování dokončeno. Unikátních proxy připraveno: $TOTAL"
echo "--------------------------------------------------------"

# ==========================================
# Mubeng Check
# ==========================================
echo "[*] Spouštím Mubeng checker..."
mubeng -f "$DB_FILE" -c t 15s -o "$LIVE_FILE"

echo "--------------------------------------------------------"

# ==========================================
# Výsledek
# ==========================================
if [ -f "$LIVE_FILE" ]; then
    LIVE_TOTAL=$(wc -l < "$LIVE_FILE")
    echo "[✔] Skript dokončen."
    echo "[✔] Získáno $LIVE_TOTAL prověřených a živých proxy."
else
    echo "[!] Nastala chyba nebo nebyla nalezena žádná živá proxy."
fi
